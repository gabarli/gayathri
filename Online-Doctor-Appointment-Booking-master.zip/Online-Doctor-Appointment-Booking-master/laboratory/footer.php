<head>
<link href="css/dashboard.css" rel="stylesheet">
</head>
<footer>
	<span class="title">
		<p>Unite Clinic</p>
	</span>
	<span class="right title">
		<p>All right reserved &copy;</p>
	</span>
</footer>
</body>
<html>